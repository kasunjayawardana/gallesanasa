$(document).ready(function () {

    $('body').hide();

    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    $.post("https://webadmin.crplk.com/api/auth/login/", {"username": "galle_union_web", "password": 'aRGIiSS)p-niG0#3hyuO6Y9U'})

        .done(function (data) {


            // Latest News
            $.ajax({
                url: "https://webadmin.crplk.com/api/news_events/?type=news&status=1",
                headers: {"Authorization": "JWT " + data.access},
                type: "GET",
                success: function (index_news) {

                    var news = index_news.sort(function (a, b) {
                        if (a.date < b.date) {
                            return 1;
                        }
                        if (a.date > b.date) {
                            return -1;
                        }
                        return 0;
                    })

                    $.each(news, function (i, index_news) {
                        if (i < 9) {
                            var d = new Date(index_news.date);
                            var date = (("0" + d.getDate()).slice(-2)) + ' ' + ((monthNames[d.getMonth()]).toUpperCase()) + ' ' + (d.getFullYear());

                            let $index_news = $('#index_news');
                            $index_news.append('<div class="col-lg-4 col-md-6">' +
                                '<div class="news-card"><div class="news-img"><a href="news-details.html">' +
                                '<img src="' + index_news.thumbnail + '" alt="News Images">' +
                                '</a></div><ul>' +
                                '<li>' + date + '</li>' +
                                '</ul><div class="news-content">' +
                                '<a href="#">' +
                                '<h3>' + index_news.title + '</h3></a>' +
                                '<p>' + index_news.description + '</p>' +
                                '</div></div></div>');
                            i++;
                        }
                    });

                    $('body').show();
                }
            })

            $.ajax({
                url: "https://webadmin.crplk.com/api/auth/logout/",
                headers: {"Authorization": "JWT " + data.access},
                type: "POST",
                data: {"refresh": data.refresh},

                success: function (logout) {
                    console.log(logout.status)

                }
            })

        })
})