$(document).ready(function () {

    $('body').hide();

    $.post("https://webadmin.crplk.com/api/auth/login/", {"username": "galle_union_web", "password": 'aRGIiSS)p-niG0#3hyuO6Y9U'})

        .done(function (data) {

            // Latest News
            $.ajax({
                url: "https://webadmin.crplk.com/api/files/?file_type_id=1&file_category_id=23&file_group_id=139&status=1",
                headers: {"Authorization": "JWT " + data.access},
                type: "GET",
                success: function (downloads_group) {

                    $.each(downloads_group, function (i, downloads_group) {
                            $('#downloads').append('<div class="col-lg-2 col-sm-4">' +
                                '<div class="trainer-card"><a href="'+ downloads_group.file +'" target="_blank">' +
                                '<img src="assets/img/about/1200px-PDF_file_icon.svg.png" alt="Trainers Images">' +
                                '</a><div class="trainer-content"><a href="'+ downloads_group.file +'" target="_blank">' +
                                '<h5 class="ms-2 me-2">' + downloads_group.title +
                                '</h5></a></div></div></div>');
                    });

                    $('body').show();
                }
            })

            $.ajax({
                url: "https://webadmin.crplk.com/api/auth/logout/",
                headers: {"Authorization": "JWT " + data.access},
                type: "POST",
                data: {"refresh": data.refresh},

                success: function (logout) {
                    console.log(logout.status)

                }
            })

        })
})